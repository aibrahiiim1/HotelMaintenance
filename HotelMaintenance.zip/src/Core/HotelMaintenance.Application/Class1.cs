﻿namespace HotelMaintenance.Application;

public class Class1
{

}
