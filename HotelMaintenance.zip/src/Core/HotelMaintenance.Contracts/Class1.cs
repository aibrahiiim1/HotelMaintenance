﻿namespace HotelMaintenance.Contracts;

public class Class1
{

}
