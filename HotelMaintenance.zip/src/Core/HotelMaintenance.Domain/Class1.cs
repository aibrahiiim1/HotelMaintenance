﻿namespace HotelMaintenance.Domain;

public class Class1
{

}
