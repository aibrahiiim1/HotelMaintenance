﻿namespace HotelMaintenance.Infrastructure;

public class Class1
{

}
