﻿namespace HotelMaintenance.Persistence;

public class Class1
{

}
